// ============================================================
// KRISHI RAKSHAK - MANDI PRICE (FRONTEND API)
// Direct data.gov.in call - no backend proxy
// ============================================================

document.addEventListener("DOMContentLoaded", () => {

    // --------------------------------------------------------
    // EXISTING MANDI UI ELEMENTS
    // --------------------------------------------------------
    const stateSelect = document.getElementById("state");
    const districtSelect = document.getElementById("district");
    const cropSelect = document.getElementById("crop");
    const mandiButton = document.getElementById("mandi-price");
    const mandiStatus = document.getElementById("mandiStatus");
    const mandiResult = document.getElementById("priceResult");

    if (!stateSelect || !districtSelect || !cropSelect || !mandiButton) {
        console.error("Mandi elements नहीं मिले।");
        return;
    }

    // --------------------------------------------------------
    // DATA.GOV.IN CONFIG
    // NOTE: Frontend API call means this public API key is visible
    // in browser/network requests. Use a restricted/public key.
    // --------------------------------------------------------
    const MANDI_API_KEY = "579b4666ec23d000cb26a97a45b479c18c489c47b";
    const MANDI_RESOURCE_ID = "9ef84268-d-465308-a864a43d0070";
    const MANDI_API_URL =
        `https://api.data.gov.in/resource/${MANDI_RESOURCE_ID}`;

    const states = [
        "Uttar Pradesh",
        "Punjab",
        "Haryana",
        "Maharashtra",
        "Madhya Pradesh"
    ];

    // --------------------------------------------------------
    // HELPERS
    // --------------------------------------------------------
    function status(message) {
        if (mandiStatus) mandiStatus.textContent = message;
    }

    function escapeHTML(value) {
        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function uniqueSorted(values) {
        return [...new Set(
            values
                .map(value => String(value || "").trim())
                .filter(Boolean)
        )].sort((a, b) => a.localeCompare(b));
    }

    function buildApiUrl(params = {}) {
        const url = new URL(MANDI_API_URL);

        url.searchParams.set("api-key", MANDI_API_KEY);
        url.searchParams.set("format", "json");
        url.searchParams.set("limit", String(params.limit || 1000));

        if (params.offset) {
            url.searchParams.set("offset", String(params.offset));
        }

        if (params.state) {
            url.searchParams.set("filters[state]", params.state);
        }

        if (params.district) {
            url.searchParams.set("filters[district]", params.district);
        }

        if (params.commodity) {
            url.searchParams.set("filters[commodity]", params.commodity);
        }

        return url.toString();
    }

    // Direct browser -> data.gov.in request.
    async function fetchMandiPage(params = {}) {
        const response = await fetch(buildApiUrl(params), {
            method: "GET",
            headers: {
                "Accept": "application/json"
            },
            cache: "no-store"
        });

        const text = await response.text();
        let data;

        try {
            data = JSON.parse(text);
        } catch {
            throw new Error(
                `Mandi API ने सही JSON response नहीं दिया (HTTP ${response.status}).`
            );
        }

        if (!response.ok) {
            throw new Error(
                data?.error ||
                data?.message ||
                `Mandi API HTTP ${response.status}`
            );
        }

        return data;
    }

    // Fetch multiple pages where needed. This keeps district/crop
    // dropdowns much more complete than a single 1000-record call.
    async function fetchAllMandiRecords(filters = {}, maxPages = 20) {
        const records = [];
        const pageSize = 1000;

        for (let page = 0; page < maxPages; page++) {
            const data = await fetchMandiPage({
                ...filters,
                limit: pageSize,
                offset: page * pageSize
            });

            const pageRecords = Array.isArray(data?.records)
                ? data.records
                : [];

            records.push(...pageRecords);

            if (pageRecords.length < pageSize) {
                break;
            }
        }

        return records;
    }

    // --------------------------------------------------------
    // INITIAL UI
    // --------------------------------------------------------
    stateSelect.innerHTML = `<option value="">State चुनें</option>`;

    states.forEach(state => {
        const option = document.createElement("option");
        option.value = state;
        option.textContent = state;
        stateSelect.appendChild(option);
    });

    districtSelect.innerHTML = `<option value="">Select District</option>`;
    cropSelect.innerHTML = `<option value="">पहले District चुनें</option>`;

    districtSelect.disabled = true;
    cropSelect.disabled = true;
    mandiButton.disabled = true;

    status("State चुनकर mandi prices देखें।");

    // --------------------------------------------------------
    // STATE -> DISTRICT
    // --------------------------------------------------------
    stateSelect.addEventListener("change", async () => {
        const state = stateSelect.value;

        districtSelect.disabled = true;
        cropSelect.disabled = true;
        mandiButton.disabled = true;

        districtSelect.innerHTML = `<option value="">Select District</option>`;
        cropSelect.innerHTML = `<option value="">पहले District चुनें</option>`;

        if (mandiResult) {
            mandiResult.innerHTML = `
                <h5>Mandi Price <small id="priceDate"></small></h5>
                <p>Market: <span id="marketName">-</span></p>
                <p>Crop: <span id="cropName">-</span></p>
            `;
        }

        if (!state) {
            status("State चुनें।");
            return;
        }

        districtSelect.innerHTML =
            `<option value="">Districts load हो रहे हैं...</option>`;
        status("Districts data.gov.in से load हो रहे हैं...");

        try {
            const records = await fetchAllMandiRecords({ state });
            const districts = uniqueSorted(
                records.map(record => record.district)
            );

            if (!districts.length) {
                throw new Error("इस State के लिए District नहीं मिली।");
            }

            districtSelect.innerHTML =
                `<option value="">Select District</option>`;

            districts.forEach(district => {
                const option = document.createElement("option");
                option.value = district;
                option.textContent = district;
                districtSelect.appendChild(option);
            });

            districtSelect.disabled = false;
            status(`${districts.length} Districts मिल गए।`);
        } catch (error) {
            console.error("Mandi District Error:", error);

            districtSelect.innerHTML =
                `<option value="">District नहीं मिली</option>`;

            status(error.message || "District load नहीं हो सकी।");
        }
    });

    // --------------------------------------------------------
    // DISTRICT -> CROP
    // --------------------------------------------------------
    districtSelect.addEventListener("change", async () => {
        const state = stateSelect.value;
        const district = districtSelect.value;

        cropSelect.disabled = true;
        mandiButton.disabled = true;

        if (!district) {
            cropSelect.innerHTML =
                `<option value="">पहले District चुनें</option>`;
            status("District चुनें।");
            return;
        }

        cropSelect.innerHTML =
            `<option value="">Crops load हो रही हैं...</option>`;
        status("Crops data.gov.in से load हो रही हैं...");

        try {
            const records = await fetchAllMandiRecords({
                state,
                district
            });

            const crops = uniqueSorted(
                records.map(record => record.commodity)
            );

            if (!crops.length) {
                throw new Error("इस District के लिए Crop नहीं मिली।");
            }

            cropSelect.innerHTML =
                `<option value="">Select Crop</option>`;

            crops.forEach(crop => {
                const option = document.createElement("option");
                option.value = crop;
                option.textContent = crop;
                cropSelect.appendChild(option);
            });

            cropSelect.disabled = false;
            status(`${crops.length} Crops मिल गईं।`);
        } catch (error) {
            console.error("Mandi Crop Error:", error);

            cropSelect.innerHTML =
                `<option value="">Crop नहीं मिली</option>`;

            status(error.message || "Crop load नहीं हो सकी।");
        }
    });

    // --------------------------------------------------------
    // CROP -> ENABLE PRICE BUTTON
    // --------------------------------------------------------
    cropSelect.addEventListener("change", () => {
        mandiButton.disabled = !cropSelect.value;

        if (cropSelect.value) {
            status("अब भाव देखें पर क्लिक करें।");
        }
    });

    // --------------------------------------------------------
    // PRICE
    // --------------------------------------------------------
    mandiButton.addEventListener("click", async () => {
        const state = stateSelect.value;
        const district = districtSelect.value;
        const commodity = cropSelect.value;

        if (!state || !district || !commodity) {
            status("State, District और Crop चुनें।");
            return;
        }

        const oldText = mandiButton.innerHTML;
        mandiButton.disabled = true;
        mandiButton.innerHTML =
            `<span class="spinner-border spinner-border-sm me-2"></span>Loading...`;

        status("Mandi prices data.gov.in से load हो रहे हैं...");

        try {
            const data = await fetchMandiPage({
                state,
                district,
                commodity,
                limit: 1000
            });

            const records = Array.isArray(data?.records)
                ? data.records
                : [];

            if (!records.length) {
                if (mandiResult) {
                    mandiResult.innerHTML = `
                        <h5>Mandi Price</h5>
                        <div class="alert alert-warning mt-3">
                            इस Crop का mandi price अभी उपलब्ध नहीं है।
                        </div>
                    `;
                }

                status("Price data नहीं मिला।");
                return;
            }

            let html = `
                <h5>Mandi Price <small>${escapeHTML(
                    records[0]?.arrival_date || ""
                )}</small></h5>
                <p>State: <span>${escapeHTML(state)}</span></p>
                <p>District: <span>${escapeHTML(district)}</span></p>
                <p>Crop: <span>${escapeHTML(commodity)}</span></p>

                <div class="table-responsive mt-3">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>मंडी</th>
                                <th>Crop</th>
                                <th>Date</th>
                                <th>Min Price</th>
                                <th>Max Price</th>
                                <th>Modal Price</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            records.forEach(record => {
                const market = record.market || record.market_name || "-";
                const crop = record.commodity || commodity || "-";
                const date = record.arrival_date || record.arrivalDate || "-";
                const min = record.min_price ?? "-";
                const max = record.max_price ?? "-";
                const modal = record.modal_price ?? "-";

                html += `
                    <tr>
                        <td>${escapeHTML(market)}</td>
                        <td>${escapeHTML(crop)}</td>
                        <td>${escapeHTML(date)}</td>
                        <td>₹${escapeHTML(String(min))}</td>
                        <td>₹${escapeHTML(String(max))}</td>
                        <td><strong>₹${escapeHTML(String(modal))}</strong></td>
                    </tr>
                `;
            });

            html += `
                        </tbody>
                    </table>
                </div>
            `;

            if (mandiResult) {
                mandiResult.innerHTML = html;
            }

            status(`${records.length} mandi records मिले।`);
        } catch (error) {
            console.error("Mandi Price Error:", error);

            if (mandiResult) {
                mandiResult.innerHTML = `
                    <h5>Mandi Price</h5>
                    <div class="alert alert-danger mt-3">
                        Mandi price load नहीं हो सका।<br>
                        ${escapeHTML(error.message || "API error")}
                    </div>
                `;
            }

            status(
                "Mandi API से data नहीं मिला। Browser console में error देखें।"
            );
        } finally {
            mandiButton.disabled = false;
            mandiButton.innerHTML = oldText;
        }
    });
});
